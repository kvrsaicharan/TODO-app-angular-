import { Component, OnInit } from '@angular/core';
import { Todo } from 'src/app/model/todo.model';
import { Router } from '@angular/router';
import { TodosService } from 'src/app/services/todos.service';

@Component({
  selector: 'app-list-todo',
  templateUrl: './list-todo.component.html',
  styleUrls: ['./list-todo.component.css']
})
export class ListTodoComponent implements OnInit {

  //creating an Array of Todo class
  todos: Todo[];


  //constructor dependency Injection
  constructor(private router: Router, private todoService: TodosService) { }

  

  //Delete Task
  deleteTask(todo: Todo): void {
    let result = confirm("Do you want to delete todo?");
    if (result) {
      this.todoService.deleteTodo(todo.id)
        .subscribe(data => {
          this.todos = this.todos.filter
            (t => t !== todo);
        })
      alert(`${todo.taskName} record is deleted..!`);


    }
  }

  //Modify Task
  editTask(todo: Todo): void {

    this.router.navigate(['edit-task', todo.id.toString()]);
  }
  //Add New Task
  addTask(): void {
    this.router.navigate(['add-task']);
  }

  //loading all users as soon as component gets loaded
  ngOnInit() {

    if (localStorage.getItem("username") != null) {
      this.todoService.getTodos()
        .subscribe(data => {
          this.todos = data;
        });
    }
    else {
      this.router.navigate(['/login']);
    }
  }

}

