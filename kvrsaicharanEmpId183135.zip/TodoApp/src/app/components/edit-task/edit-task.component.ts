import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Todo } from 'src/app/model/todo.model';
import { Router, ActivatedRoute } from '@angular/router';
import { TodosService } from 'src/app/services/todos.service';

@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css']
})
export class EditTaskComponent implements OnInit {

  editForm: FormGroup;
  submitted: boolean = false;
  todo: Todo;
  todoId: string;
  constructor(private formBuilder: FormBuilder, private router: Router,
    private route: ActivatedRoute,
    private todoService: TodosService) {
    this.route.params.subscribe(params => this.todoId = params['id']);
    console.log(this.todoId);
  }
  
  ngOnInit() {
    
    if (this.todoId != null) {
      if (!this.todoId) {
        alert('Invalid Action');
        this.router.navigate(['list-todo']);
        return;
      }
      this.editForm = this.formBuilder.group({
        id: [],
        taskName: ['',Validators.required],
        taskStatus:['',Validators.required]
        
      });

      
      this.todoService.getTodosById(+this.todoId).subscribe(data => {
        this.editForm.setValue(data)
      });
    }
    else {
      this.router.navigate(['/login']);
    }
  }//end of ngOnInit() function

  onSubmit() {
    this.submitted = true;
    if (this.editForm.invalid) {
      return;
    }

    this.todoService.updateTodo(this.editForm.value)
      //.pipe(first())
      .subscribe(data => {
        this.router.navigate(['list-todo']);
      }, error => {
        alert(error);
      });

  }

}

